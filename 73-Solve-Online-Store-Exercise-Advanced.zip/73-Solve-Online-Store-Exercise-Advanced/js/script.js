var anbarKala=[
    {id:1, kalaName:"floor cleaning liquid", kalaCount: 10, kalaPrice:4000},
    {id:2, kalaName:"body shampoo", kalaCount: 20, kalaPrice:2000},
    {id:3, kalaName:"dish washer", kalaCount: 15,  kalaPrice:400},
    {id:4, kalaName:"laundry liquid", kalaCount: 30,  kalaPrice:3000},
    {id:5, kalaName:"hair shampoo", kalaCount: 5,  kalaPrice:1500},
    {id:6, kalaName:"tooth brush", kalaCount: 1, kalaPrice:2000},
    {id:7, kalaName:"tooth paste", kalaCount: 2, kalaPrice:1000},
    {id:8, kalaName:"hair brush", kalaCount: 1,  kalaPrice:2500},
]

var userBasket=[
    {id:6, kalaName:"tooth brush", kalaCount: 1, kalaPrice:2000},
    {id:7, kalaName:"tooth paste", kalaCount: 2, kalaPrice:1000},
    {id:8, kalaName:"hair brush", kalaCount: 1,  kalaPrice:2500},
]
var isExit=false,userAns=false


while (true){
    while(true)
    {
        isAddDel=prompt("Please choose one of the following two options:\n1- Adding products to the shopping basket\n2- Removing the product from the shopping basket",'1')
        if(isAddDel==='1' || isAddDel==='2')    break
        else{
            alert("You chose the wrong option.\nYou should have chosen one of the following two options:\n1- Adding products to the shopping basket\n2- Removing the product from the shopping basket\n\nClick ok to continue.")
        } 
    }

    var kalaRequest={id:0, kalaName:"", kalaCount: 0, kalaPrice:0}
    var isName=false
    var isCount=false

    if(isAddDel==='1'){
        var userBasketList=""
        userBasket.forEach(function(x){
            userBasketList+=("Id: "+x.id+ "-> Kala Name: "+x.kalaName+"-> kala Count: "+x.kalaCount+"-> kala Price: "+x.kalaPrice+"\n")
        })
        
        alert("Products in the user's shopping basket:\n\n"+userBasketList)
    
        var anbarKalaList=""
        anbarKala.forEach(function(x){
            anbarKalaList+=("Id: "+x.id+ "-> Kala Name: "+x.kalaName+"-> kala Count: "+x.kalaCount+"-> kala Price: "+x.kalaPrice+"\n")
        })
        
        alert("Products in the anbar:\n\n"+anbarKalaList)    

        var Name=prompt("Enter kala name:").toLowerCase()
        var Count=Number(prompt("Enter kala count:").toLowerCase())

        isExit= anbarKala.some(function(x){
            isName=x.kalaName===Name
            isCount=x.kalaCount>=Count
            if( isName===true && isCount===true){
                kalaRequest=x
                return true
            }
        })


        if(isExit===true){
            var userKala={
                id:kalaRequest.id, 
                kalaName:Name, 
                kalaCount:Count, 
                kalaPrice:kalaRequest.kalaPrice * Count,
            }

            userBasket.push(userKala)

        }
        else{
            if(isName===false){
                alert("There is not this kala in anbar.")
            }
            else{
                alert("The count of this kala is not enough.")
            }
        }
    }

    else{

        var userBasketList=""
        userBasket.forEach(function(x){
            userBasketList+=("Id: "+x.id+ "-> Kala Name: "+x.kalaName+"-> kala Count: "+x.kalaCount+"-> kala Price: "+x.kalaPrice+"\n")
        })
        
        alert("Products in the user's shopping basket:\n\n"+userBasketList)

        var Name=prompt("Enter kala name:").toLowerCase()

        var kalaIndext= userBasket.findIndex(function(x){
            return x.kalaName===Name
        })


        if(kalaIndext!==-1){
            userBasket.splice(kalaIndext,1)
        }
        else{
            alert("There is not this kala in shopping basket of user.")
        }
    }


    userAns=confirm("Do you want another kala?")
    if(userAns===false){
        alert("At the continue, We display user's basket->")
        break
    }
    
}

var userBasketList=""
var sumPrices=0
userBasket.forEach(function(x){
    userBasketList+=("Id: "+x.id+ "-> Kala Name: "+x.kalaName+"-> kala Count: "+x.kalaCount+"-> kala Price: "+x.kalaPrice+"\n")
    sumPrices+=x.kalaPrice
})

alert(userBasketList+"\n\nSum of prices: "+sumPrices)